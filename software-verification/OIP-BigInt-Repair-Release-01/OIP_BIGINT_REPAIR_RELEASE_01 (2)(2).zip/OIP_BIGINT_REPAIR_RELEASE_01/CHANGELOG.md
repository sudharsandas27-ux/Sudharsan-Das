# Changelog
## OIP BigInt Repair Release Candidate 01

### Added
- Separate HK009 BigInt repair candidate.
- Separate UC004 BigInt hashing repair candidate.
- Supplemental verification records for both candidates.
- Combined BigInt repair reconciliation evidence.
- Final verification report.

### Verification
- HK009: 18/18 formal checks passed.
- UC004: 20/20 formal checks passed.
- Combined: 38/38 formal checks passed.
- HK009 diagnostic probes: 7, excluded from formal totals.

### Historical Records
- Preserved original historical verification files.
- Historical results remain 105 PASS, 2 FAIL, 1 expected policy rejection.
- Historical records were not rewritten.

### Limitations
- Full historical regression of repair candidates not performed.
- Cross-runtime canonical serialization remains OPEN.
- No measurement authorization, empirical/scientific validation,
  production release approval, or engine lock approval.
