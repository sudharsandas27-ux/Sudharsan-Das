# OIP BigInt Repair Release Candidate 01

Stage: Research-stage repair candidate package.

This package contains separate BigInt repair candidates for HK009 and UC004,
their supplemental verification records, and a combined reconciliation record.

## Supplemental verification

- HK009: 18/18 formal checks PASS.
- UC004: 20/20 formal checks PASS.
- Combined supplemental formal checks: 38/38 PASS.
- HK009 diagnostic probes: 7, excluded from formal pass/fail totals.

## Historical verification

The original 108-execution history is preserved separately.
It records 105 PASS, 2 FAIL, and 1 expected policy rejection.
These historical results have not been rewritten or erased.

## Scope and limitations

- Targeted supplemental repair verification only.
- Full historical regression of the new repair candidates: NOT PERFORMED.
- Cross-runtime canonical serialization: OPEN.
- No empirical validation established.
- No scientific validation established.
- No measurement authorization.
- No production release approval.
- No engine lock approval.

The HK009 repair retains fail-closed INVALID_INPUT behaviour for formula
outputs that cannot satisfy the finite native numeric result contract.

The historical files are preserved as historical evidence and should not
be interpreted as the final status of the new repair candidates.

This package is a release candidate for further review, not a production release.
